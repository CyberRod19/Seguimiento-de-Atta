function expmt = tempphototaxis_sub_gui(expmt)

expmt = slowphototaxis_parameter_sub_gui(expmt);