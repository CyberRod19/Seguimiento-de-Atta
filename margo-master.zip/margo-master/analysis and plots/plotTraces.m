function plotTraces(expmt)

traceplot_subgui(expmt)