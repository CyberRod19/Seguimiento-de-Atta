function [optoChoice,rightTurns]=analyzeTurns(current_arm,changedArm,previous_arm)




end